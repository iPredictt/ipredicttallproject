from django import forms
from django.forms import ModelForm
from company.models import MasterCompany,MasterIndustry

class CompanyForm(ModelForm):
	class Meta:
		model = MasterCompany
		#exclude = ['company_id','company_name','revenue','employee_count','industry','source']
		exclude = ['created_at','updated_at']
		widgets = {
          'company_name': forms.TextInput(attrs={'size':'50'}),
        }