# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404,render_to_response
# Create your views here.
from .forms import CompanyForm
from company.models import MasterCompany,UserExperience
import sys
import string
from nltk.corpus import stopwords
import difflib
import pandas as pd
from django.db import connection
from django.forms import modelformset_factory,BaseModelFormSet
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from paginated_modelformset import PaginatedModelFormSet
from django.contrib.auth.decorators import login_required

def add(request):
    print('ADD REquest')
    if request.method == "POST":
        form = CompanyForm(request.POST)
        if form.is_valid():
            # commit=False means the form doesn't save at this time.
            # commit defaults to True which means it normally saves.
            model_instance = form.save(commit=False)
            #model_instance.timestamp = timezone.now()
            model_instance.save()
            return redirect('company:list')
    else:
        form = CompanyForm()
    return render(request, "company_master.html", {'form': form})

#@login_required(login_url='/home/login/')
def list(request):
    #colleges = MasterCollege.objects.all()
    companys=MasterCompany.objects.raw("SELECT * FROM master_company where source is null")
    #    for college in colleges:
    #       print ("Colleges List:"+college.college_name)
    #data = {}
    #data['object_list'] = colleges
    #print(type(data))
    #print(type(colleges))
    return render(request, 'company_list.html', {'lstData':companys})


def update(request, pk):
   # print("college update call.."+pk)
    company = get_object_or_404(MasterCompany, pk=pk)
   # print (college.college_name)
    form = CompanyForm(request.POST or None, instance=company)
     #print(form)
    #print(form['college_name'].value())
    if form.is_valid():
        form.save()
        return redirect('company:list')
    return render(request,"company_master.html",{'form':form})

def confirm_replace(request, pk,pk2):
   # print("college update call.."+pk)
   # college = get_object_or_404(MasterCollege, pk=pk)
    print("Confirm replace::"+pk +" :::"+pk2)
    if request.method=='POST':
        with connection.cursor() as cursor:
            cursor.execute("UPDATE user_experience SET company_id = %s WHERE company_id = %s", [pk2,pk])
        company = get_object_or_404(MasterCompany, pk=pk)
        company.delete()
        return redirect('company:list') 
    else:
       return render(request, 'company_confirm_replace.html', {'pk':pk,'pk2':pk2})

def replace(request, pk):
   # print("college update call.."+pk)
    company = get_object_or_404(MasterCompany, pk=pk)
   # print (college.college_name)
   # if request.method=='POST':
   #    return render('college_confirm_replace.html',{object : college})

    form = CompanyForm(request.POST or None, instance=company)
    col_name=company.company_name
    col_name2=company.company_name
    col_name = [word for word in col_name.split() if word.lower() not in stopwords.words('english')]
    strwh=''
    lst2=[]
    j=0
    for cname in col_name:
        j+=1
        if ((j==len(col_name)) | (len(col_name)==1)):
            strwh=strwh +" company_name like %s "
            lst2.append("%"+cname+"%")
            break
        else:
            strwh=strwh +" company_name like %s or"
            lst2.append("%"+cname+"%")
    print(strwh)
    #qry="SELECT * FROM master_company where company_id!="+str(pk)+" and ("+strwh +")"
    qry="SELECT * FROM master_company where company_id!="+str(pk)
    print(qry)
    print(lst2)
    #["%high%","%school%"]
    companys=MasterCompany.objects.raw(qry)
    print(type(companys))
    dataLst=[]
    for obj1 in companys:
        #print ("Colleges List:"+type(college.college_acronym))
        #college.college_acronym != None
        if (name_compare_n2(col_name2,obj1.company_name)==1):
            dataLst.append(obj1)
    # print ("Colleges List:"+college.college_name)
    #print(colgLst)
    #data = {}
    #data['object_list'] = colleges    
    # print(colleges)
    #print(form['college_name'].value())
    if form.is_valid():
        form.save()
        return redirect('company:list')
    return render(request,"company_edit.html",{'form':form,'lstData':dataLst,'pk':pk})

def delete(request, pk, template_name='company_delete.html'):
    company = get_object_or_404(MasterCompany, pk=pk)
    if request.method=='POST':
        company.delete()
        return redirect('company:list')
    return render(request, template_name, {'object1':company})


def name_compare_n2(val1,val2):
    seq = difflib.SequenceMatcher()
    r1=0;
    seq = difflib.SequenceMatcher()
    seq.set_seqs(val1, val2)
    if ((seq.ratio()*100)>60):
        print("match:"+val2)
        return 1
    else:
        return 0


def allupdates(request):
    print("Call updates")
    #candidate_exp=CandidateExperience.objects.raw("SELECT * FROM candidate_experience where candidate_id=%s",[pk])
    search_val=''
    if request.method == 'GET': # If the form is submitted
        search_val = request.GET.get('search_box', None) 
        print(search_val) 
        if (search_val==None):
            search_val=''
    if request.method == 'POST':
        companyFormSet = modelformset_factory(MasterCompany,form=CompanyForm)
        form_list = companyFormSet(request.POST)
        action = request.POST.get('action')
        if action==u'delete':
            form_list.save()
        else: 
            instances=form_list.save(commit=False)
            for instance in instances:
                instance.save()

    companyFormSet = modelformset_factory(MasterCompany, form=CompanyForm,formset=PaginatedModelFormSet)
       # form_list = companyFormSet(per_page=20, page_num=1)
    '''
    paginator = Paginator(Blog.objects.all(), 1)

    try:
        page = int(request.GET.get('page', '1'))
    except:
        page = 1

    try:
        blogs = paginator.page(page)
    except(EmptyPage, InvalidPage):
        blogs = paginator.page(1)
    '''
    page = request.GET.get('page')
    try:
        form_list = companyFormSet(queryset = MasterCompany.objects.filter(company_name__icontains=search_val),per_page=20, page_num=page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        form_list = companyFormSet(queryset = MasterCompany.objects.filter(company_name__icontains=search_val),per_page=20, page_num=1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        form_list = companyFormSet(queryset = MasterCompany.objects.filter(company_name__icontains=search_val),per_page=20, page_num=paginator.num_pages)
    '''
    # Get the index of the current page
    if (page=='None')
        page=1
    index = page - 1  # edited to something easier without index
    # This value is maximum index of your pages, so the last page - 1
    max_index = len(paginator.num_pages)
    # You want a range of 7, so lets calculate where to slice the list
    start_index = index - 3 if index >= 3 else 0
    end_index = index + 3 if index <= max_index - 3 else max_index
    # My new page range
    page_range = paginator.page_range[start_index:end_index]    
    ''' 
    #companyFormSet = modelformset_factory(MasterCompany,form=CompanyForm)
    form_lbl = CompanyForm()
    return render(request, 'edit_master.html', {'formset':form_list,'formlable':form_lbl,'search_val':search_val,'search_label':'Company Name'})    
