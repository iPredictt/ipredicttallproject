from __future__ import unicode_literals

from django.db import models
from django import forms
# Create your models here.

class MasterIndustry(models.Model):
    industry_id = models.AutoField(primary_key=True)
    industry = models.CharField(max_length=100, blank=True, null=True)
    source = models.CharField(max_length=20, blank=True, null=True)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_industry'

    def __str__(self):
        return self.industry  

class MasterCompany(models.Model):
    company_id = models.AutoField(primary_key=True)
    company_name = models.CharField(max_length=400, blank=True, null=True)
    revenue = models.FloatField(blank=True, null=True)
    employee_count = models.FloatField(blank=True, null=True)
    #industry_id = models.FloatField(blank=True, null=True)
    #industry = models.ForeignKey('MasterIndustry', models.DO_NOTHING, blank=True, null=True)
    source_name= (
    ('admin', 'Admin'),
    ('web', 'Website'),
    )
    source = models.CharField(max_length=40,choices=source_name, default='admin')       
    #source = models.CharField(max_length=40, blank=True, null=True)
    careeropportunitiesrating = models.FloatField(db_column='careerOpportunitiesRating', blank=True, null=True)  # Field name made lowercase.
    compensationandbenefitsrating = models.FloatField(db_column='compensationAndBenefitsRating', blank=True, null=True)  # Field name made lowercase.
    cultureandvaluesrating = models.FloatField(db_column='cultureAndValuesRating', blank=True, null=True)  # Field name made lowercase.
    industry = models.CharField(max_length=100, blank=True, null=True)
    overallrating = models.FloatField(db_column='overallRating', blank=True, null=True)  # Field name made lowercase.
    seniorleadershiprating = models.FloatField(db_column='seniorLeadershipRating', blank=True, null=True)  # Field name made lowercase.
    worklifebalancerating = models.FloatField(db_column='workLifeBalanceRating', blank=True, null=True)  # Field name made lowercase.
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_company'

   # def __str__(self):              # __unicode__ on Python 2
   #    return self.company_name
class UserExperience(models.Model):
    user_experience_id = models.AutoField(primary_key=True)
    #user = models.ForeignKey('UserLogin', models.DO_NOTHING)
    company_id = models.IntegerField(blank=True, null=True)
    city_id = models.IntegerField(blank=True, null=True)
    designation_id = models.IntegerField()
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    ctc = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_experience'
       