# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404,render_to_response
# Create your views here.
from .forms import CollegeForm
from college.models import MasterCollege,UserQualification
import sys
import string
from nltk.corpus import stopwords
import difflib
import pandas as pd
from django.db import connection
from django.forms import modelformset_factory,BaseModelFormSet
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from paginated_modelformset import PaginatedModelFormSet

def add(request):
    print('Call college Add')
    if request.method == "POST":
        form = CollegeForm(request.POST)
        if form.is_valid():
            # commit=False means the form doesn't save at this time.
            # commit defaults to True which means it normally saves.
            model_instance = form.save(commit=False)
            #model_instance.timestamp = timezone.now()
            model_instance.save()
            return redirect('college:list')
    else:
        form = CollegeForm()
    return render(request, "college_master.html", {'form': form})

def list(request):
    #colleges = MasterCollege.objects.all()
    colleges=MasterCollege.objects.raw("SELECT * FROM master_college where source is null")
    #    for college in colleges:
    #       print ("Colleges List:"+college.college_name)
    #data = {}
    #data['object_list'] = colleges
    #print(type(data))
    #print(type(colleges))
    return render(request, 'college_list.html', {'colData':colleges})


def update(request, pk):
   # print("college update call.."+pk)
    college = get_object_or_404(MasterCollege, pk=pk)
   # print (college.college_name)
    form = CollegeForm(request.POST or None, instance=college)
     #print(form)
    #print(form['college_name'].value())
    if form.is_valid():
        form.save()
        return redirect('college:list')
    return render(request,"college_master.html",{'form':form})

def confirm_replace(request, pk,pk2):
   # print("college update call.."+pk)
   # college = get_object_or_404(MasterCollege, pk=pk)
    print("Confirm replace::"+pk +" :::"+pk2)
    if request.method=='POST':
        with connection.cursor() as cursor:
            cursor.execute("UPDATE user_qualification SET college_id = %s WHERE college_id = %s", [pk2,pk])
        college = get_object_or_404(MasterCollege, pk=pk)
        college.delete()
        return redirect('college:list') 
    else:
       return render(request, 'college_confirm_replace.html', {'pk':pk,'pk2':pk2})

def replace(request, pk):
   # print("college update call.."+pk)
    college = get_object_or_404(MasterCollege, pk=pk)
   # print (college.college_name)
   # if request.method=='POST':
   #    return render('college_confirm_replace.html',{object : college})

    form = CollegeForm(request.POST or None, instance=college)
    col_name=college.college_name
    col_name2=college.college_name
    col_name = [word for word in col_name.split() if word.lower() not in stopwords.words('english')]
    strwh=''
    lst2=[]
    j=0
    for cname in col_name:
        j+=1
        if ((j==len(col_name)) | (len(col_name)==1)):
            strwh=strwh +" college_name like %s "
            lst2.append("%"+cname+"%")
            break
        else:
            strwh=strwh +" college_name like %s or"
            lst2.append("%"+cname+"%")
    print(strwh)
    qry="SELECT * FROM master_college where college_id!="+str(pk)+" and ("+strwh +")"
    print(qry)
    print(lst2)
    #["%high%","%school%"]
    colleges=MasterCollege.objects.raw(qry,lst2)
    print(type(colleges))
    colgLst=[]
    for college in colleges:
        #print ("Colleges List:"+type(college.college_acronym))
        if (name_compare_n2(col_name2,college.college_name)==1):
            colgLst.append(college)
        elif (college.college_acronym != None):
            if (name_compare_n2(col_name2,college.college_acronym)==1):
                colgLst.append(college)


           # print ("Colleges List:"+college.college_name)
    #print(colgLst)
    #data = {}
    #data['object_list'] = colleges    
    # print(colleges)
    #print(form['college_name'].value())

    if form.is_valid():
        form.save()
        return redirect('college:list')
    return render(request,"college_edit.html",{'form':form,'colData':colgLst,'pk':pk})

def delete(request, pk, template_name='college_delete.html'):
    college = get_object_or_404(MasterCollege, pk=pk)
    if request.method=='POST':
        college.delete()
        return redirect('college:list')
    return render(request, template_name, {'object1':college})


def name_compare_n2(val1,val2):
    seq = difflib.SequenceMatcher()
    r1=0;
    seq = difflib.SequenceMatcher()
    seq.set_seqs(val1, val2)
    if ((seq.ratio()*100)>60):
        print("match:"+val2)
        return 1
    else:
        return 0

def allupdates(request):
    search_val=''
    if request.method == 'GET': # If the form is submitted
        search_val = request.GET.get('search_box', None) 
        print(search_val) 
        if (search_val==None):
            search_val=''   
    if request.method == 'POST':
        dataFormSet = modelformset_factory(MasterCollege,form=CollegeForm)
        form_list = dataFormSet(request.POST)
        action = request.POST.get('action')
        if action==u'delete':
            form_list.save()
        else: 
            instances=form_list.save(commit=False)
            for instance in instances:
                instance.save()
    dataFormSet = modelformset_factory(MasterCollege, form=CollegeForm,formset=PaginatedModelFormSet)
    page = request.GET.get('page')
    print(page)
    try:
        form_list = dataFormSet(queryset = MasterCollege.objects.filter(college_name__icontains=search_val),per_page=20, page_num=page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        form_list = dataFormSet(queryset = MasterCollege.objects.filter(college_name__icontains=search_val),per_page=20, page_num=1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        form_list = dataFormSet(queryset = MasterCollege.objects.filter(college_name__icontains=search_val),per_page=20, page_num=paginator.num_pages)
    form_lbl = CollegeForm()
    return render(request, 'edit_master.html', {'formset':form_list,'formlable':form_lbl,'search_val':search_val,'search_label':'College Name'})            
