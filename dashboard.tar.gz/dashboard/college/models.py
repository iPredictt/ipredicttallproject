# Create your models here.
from __future__ import unicode_literals

from django.db import models


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'

class MasterCollege(models.Model):
    college_id = models.AutoField(primary_key=True)
    college_name = models.CharField(max_length=250, blank=True, null=True)
    college_acronym = models.CharField(max_length=45, blank=True, null=True)
    college_tier = models.IntegerField(blank=True, null=True)
    source_name= (
    ('admin', 'Admin'),
    ('web', 'Website'),
    )
    source = models.CharField(max_length=40,choices=source_name, default='admin')
    created_at = models.CharField(max_length=20, blank=True, null=True)
    updated_at = models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_college'
"""
    def __unicode__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('college_update', kwargs={'pk': self.pk})

"""
class UserQualification(models.Model):
    user_qualification_id = models.AutoField(primary_key=True)
    #user = models.ForeignKey(UserLogin, models.DO_NOTHING)
    college_id = models.IntegerField()
    degree_id = models.CharField(max_length=100, blank=True, null=True)
    city_id = models.IntegerField(blank=True, null=True)
    aggregate = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    graduation = models.IntegerField()
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_qualification'

