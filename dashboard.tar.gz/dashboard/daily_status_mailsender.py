"""
Created on Mon Jun 12 11:28:44 2017

@author: ipredictt
"""
#!/usr/bin/python


import smtplib
import pymysql
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime, timedelta
try:
    
    connection = pymysql.connect(host='54.254.219.225',user='consumercareerletics',password='consumer2017careerletics',db='consumer',charset='utf8mb4',cursorclass=pymysql.cursors.DictCursor)
    cursor = connection.cursor()
    with connection.cursor() as cursor:
        sql1 = "select COUNT(*) as `new_user` from user_login where created_at > CURDATE() - INTERVAL 1 DAY and created_at < CURDATE() "
        cursor.execute(sql1)
        result1 = cursor.fetchone()
        print result1
        newuser = result1['new_user']
        sql2 = "select COUNT(user_id) as `total_user` from user_login where created_at < CURDATE()"
        cursor.execute(sql2)
        result2 = cursor.fetchone()
        print result2
        alluser = result2['total_user']
        receipent = "rohit.v@ipredictt.com,aditya.a@ipredictt.com,satish.p@ipredictt.com,contact@fabstudio.co,kanchan.v@ipredictt.com"
        #receipent = "pankaj.j@ipredictt.com"
        msg = MIMEMultipart('alternative')
        msg['From'] = "welcome@careerletics.com"
        msg['To'] = receipent
        nowdate = datetime.today().strftime ("%d-%m-%Y")
        yesterday = datetime.today() - timedelta(days=1)
        yesterdaydate = yesterday.strftime ("%d-%m-%Y")
        msg['Subject'] = 'Daily Users count on careerletics platform'
        
        message = """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!doctype html>
<html>
    <head>
    <meta charset="utf-8">
    <!-- utf-8 works for most cases -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Forcing initial-scale shouldn't be necessary -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Careerletics</title>

<style type="text/css">
		body,html{{
			{{ padding:0px;
			margin:0px;
            word-wrap:break-word;
		}}
		table td{{
			{{ font-size:12px;
			font-family:Arial, Helvetica, sans-serif;
            word-wrap:break-word;
		}}
		a{{
			{{ text-decoration:none;
		}}
		img{{
			{{ border:0px;
		}}
        p.test{{
          width:100%;
          word-wrap:break-word;
        }}
</style></head>

<body style="background:#f4f4f4;">

<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr>
	<td align="center" style=" padding:15px;">
	
	<!-- inner main table start -->
	<table border="0" cellspacing="0" cellpadding="15" style="width:550px; max-width:550px; font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#666666; border:1px solid #ddd; background:#fff;">
		<tr>
			<td align="left" style="padding:10px;">
				<table width="100%" border="0" cellspacing="0" cellpadding="10" style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#000; ">
					<tr>
						<td align="center" style=" width="7%" ><a href="https://www.careerletics.com/" target="_blank"><img align="center" src="https://s3.ap-south-1.amazonaws.com/mysqlbackupcareerletics/careerletic_logo.jpg"></a></td>
						<td align="right" valign="middle" style="padding-right:15px; padding-top:30px; color:#333; font-size:23px; font-weight:bold;"></td>
					</tr>
				</table>
			
			</td>
		</tr>
		
		<tr>
			<td align="left" valign="top" style="padding:15px; padding-top:25px;  line-height:20px;">
				Hi,<br>
				Good day!<br>
                <p class="test"> Total count of user on """ '{0}'  """ is """ '{1}' """</p>
                
                <p class="test">No. of user joined platform on """ '{2}' """ is  """ '{3}' """</p>
                
            </td>
		</tr>
		
		<tr>
			<td align="right" valign="top" style="background:#ccc; padding:10px 15px; color:#000; font-size:12px;">
				<table width="100%" cellpadding="0" cellspacing="0" border="0" style="font-family:'Open Sans','Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:13px;">
					<tr>
						
						<td align="right">
							Powered by <a href="http://ipredictt.com/" target="_blank" style="color:#000; text-decoration:none">Ipredictt Data Science Labs</a>
						</td>
					</tr>
				</table>

				
			</td>
        </tr>
	</table>

	<!-- inner main table close -->
	
	</td>
</tr>
</table>


</body>
</html> 
     """.format(nowdate,alluser,yesterdaydate,newuser)
        part2 = MIMEText(message, 'html')
        msg.attach(part2)
        session = smtplib.SMTP('smtp.gmail.com', 587)
        session.ehlo()
        session.starttls()
        session.login("pankaj.j@ipredictt.com", 'pankaj@123')
        try:
            session.sendmail("pankaj.j@ipredictt.com",receipent.split(','),msg.as_string())
            print"Successfully sent email"
        except smtplib.SMTPException as e:
            print "Error: unable to send email", e
    
        finally:
            session.close()
                

finally:
        connection.close()
