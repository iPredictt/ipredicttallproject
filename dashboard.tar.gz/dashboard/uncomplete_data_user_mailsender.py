# -*- coding: utf-8 -*-



#!/usr/bin/python


import smtplib
import pymysql
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


def emailer_uncompletedata():
    connection = pymysql.connect(host='54.254.219.225',user='consumercareerletics',password='consumer2017careerletics',db='consumer',charset='utf8mb4',cursorclass=pymysql.cursors.DictCursor)
    cursor = connection.cursor()
    
    try:
        with connection.cursor() as cursor:
            sql = "select A.user_id,A.email,B.first_name as name from user_login A, user_profile B where A.user_id = B.user_id and A.created_at > curdate() - interval 1 day and B.user_education_score =0"
            cursor.execute(sql)
            result = cursor.fetchall()
            for item in result:
                receipent = item["email"]
                print (receipent)
                name = item["name"]
                msg = MIMEMultipart('alternative')
                msg['From'] = "welcome@careerletics.com"
                msg['To'] = receipent
                uuid = item["user_id"]
                email_type = "feature_updates"
                msg['Subject'] = 'New feature updates in Careerletics platform'


                message = """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!doctype html>
<html>
    <head>
    <meta charset="utf-8">
    <!-- utf-8 works for most cases -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Forcing initial-scale shouldn't be necessary -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Careerletics</title>

<style type="text/css">
		body,html{{
			{{ padding:0px;
			margin:0px;
            word-wrap:break-word;
		}}
		table td{{
			{{ font-size:12px;
			font-family:Arial, Helvetica, sans-serif;
            word-wrap:break-word;
		}}
		a{{
			{{ text-decoration:none;
		}}
		img{{
			{{ border:0px;
		}}
        p.test{{
          width:100%;
          word-wrap:break-word;
        }}
</style></head>

<body style="background:#f4f4f4;">

<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr>
	<td align="center" style=" padding:15px;">
	
	<!-- inner main table start -->
	<table border="0" cellspacing="0" cellpadding="15" style="width:550px; max-width:550px; font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#666666; border:1px solid #ddd; background:#fff;">
		<tr>
			<td align="left" style="padding:10px;">
				<table width="100%" border="0" cellspacing="0" cellpadding="10" style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#000; ">
					<tr>
						<td align="center" style=" width="7%" ><a href="https://www.careerletics.com/" target="_blank"><img align="center" src="https://s3.ap-south-1.amazonaws.com/mysqlbackupcareerletics/careerletic_logo.jpg"></a></td>
						<td align="right" valign="middle" style="padding-right:15px; padding-top:30px; color:#333; font-size:23px; font-weight:bold;"></td>
					</tr>
				</table>
			
			</td>
		</tr>
		
		<tr>
			<td align="left" valign="top" style="padding:15px; padding-top:25px;  line-height:20px;">

			<img src= "https://s3.ap-south-1.amazonaws.com/mysqlbackupcareerletics/synthesis.gif"> <br> <br>
				Hi """ '{0}' """ ,<br>
				Good day!<br>
                <p class="test">Thanks for registering with Careerletics – your personal career advisory. We use Data Science to help you with understanding of your career’s true potential by comparing your Career path with thousands of professionals who have taken that path.</p>
                <p class="test">We realized that you have not completed your profile on Careerletics.com. By providing us some more information, you will get better Career Synthesis, Career Recommendations regarding jobs, courses and career paths.</p>

                <p class="test">We encourage you to complete this for a superior experience.</p> 
                <p align="center"><a href="http://bit.ly/2th2CjZ" style=" align:center;background-color:#FFA500;color:#fff;display:inline-block;padding:0 40px;margin:0;border-radius:4px;font-size:16px;line-height:48px;text-align:center;text-decoration:none;vertical-align:center" target="_blank"> My Profile</a></p> 
                
                All the best,<br> 

				Team Careerletics.com<br> <br>




</td>
		</tr>
		<tr>
			<td align="center" valign="top" style=" padding:10px;">
				<table width="100%" border="0" cellspacing="0" cellpadding="10" style="background:#f8f8f8; font-family:Arial, Helvetica, sans-serif; font-size:12px;">
					
					
				</table>


			</td>
		</tr>
		<tr>
			<td align="right" valign="top" style="background:#ccc; padding:10px 15px; color:#000; font-size:12px;">
				<table width="100%" cellpadding="0" cellspacing="0" border="0" style="font-family:'Open Sans','Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:13px;">
					<tr>
						<td align="left" width="50%">
							<a href="https://www.facebook.com/Careerletics" target="_blank"><img src="https://s3.ap-south-1.amazonaws.com/mysqlbackupcareerletics/facebook.png" height="25" border="0"></a>
							<a href="https://twitter.com/Careerletics_" target="_blank"><img src="https://s3.ap-south-1.amazonaws.com/mysqlbackupcareerletics/twitter.png" height="25" border="0"></a>
							<a href="https://www.linkedin.com/in/careerletics-contact-187420136/" target="_blank"><img src="https://s3.ap-south-1.amazonaws.com/mysqlbackupcareerletics/linkedin.png" height="25" border="0"></a>
							<a href="https://www.youtube.com/channel/UCpELTJ_gZL4RlyYnrU-5y_A" target="_blank"><img src="https://s3.ap-south-1.amazonaws.com/mysqlbackupcareerletics/youtube.png" height="25" border="0"></a>
						</td>
						<td align="right">
							Powered by <a href="http://ipredictt.com/" target="_blank" style="color:#000; text-decoration:none">Ipredictt Data Science Labs</a>
						</td>
					</tr>
				</table>

				
			</td>
        </tr>
	</table>

	<!-- inner main table close -->
	
	</td>
</tr>
</table>
<div align="center"><a href="http://preferences.careerletics.com/unsubscribe-from-careerletics.html?email=""" '{1}' """&token=""" '{2}' """&type=""" '{3}' """ "style="color:#000000; text-decoration: none; font-family: arial; font-size:12px;">Click here to Unsubscribe</a></div>

</body>
</html>       """.format(name,receipent,uuid,email_type)    
                part2 = MIMEText(message, 'html')
                msg.attach(part2)
                session = smtplib.SMTP('smtp.gmail.com', 587)
                session.ehlo()
                session.starttls()
                session.login("noreply@careerletics.com", 'noreply@shubham')
                try:
                    session.sendmail("noreply@careerletics.com",receipent,msg.as_string())
                    print("Successfully sent email")
                except smtplib.SMTPException as e:
                    print ("Error: unable to send email", e)

                finally:
                    session.close()
                
            
            
    finally:
        connection.close()


if __name__ == '__main__':
    emailer_uncompletedata()


