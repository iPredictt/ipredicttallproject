from django import forms
from django.forms import ModelForm
from college.models import MasterCollege

class CollegeForm(ModelForm):
	class Meta:
		model = MasterCollege
		fields = ['college_id','college_name', 'source','college_acronym','college_tier']