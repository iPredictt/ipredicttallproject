# Create your models here.
# Create your models here.
from __future__ import unicode_literals
from django.db import models

class MasterDegree(models.Model):
    degree_id = models.AutoField(primary_key=True)
    degree_name = models.CharField(max_length=100)
    degree_acronym = models.CharField(max_length=100, blank=True, null=True)
    source_name= (
    ('admin', 'Admin'),
    ('web', 'Website'),
    )
    source = models.CharField(max_length=40,choices=source_name, default='admin')
    created_at = models.CharField(max_length=20, blank=True, null=True)
    updated_at = models.CharField(max_length=20, blank=True, null=True)
    degree_rank = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_degree'


class UserQualification(models.Model):
    user_qualification_id = models.AutoField(primary_key=True)
    user_id = models.IntegerField()
    college_id = models.IntegerField()
    degree_id = models.CharField(max_length=100, blank=True, null=True)
    start_year = models.DateTimeField(blank=True, null=True)
    end_year = models.DateTimeField(blank=True, null=True)
    aggregate = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_qualification'