# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404,render_to_response
# Create your views here.
from .forms import DegreeForm
from degree.models import MasterDegree,UserQualification
import sys
import string
from nltk.corpus import stopwords
import difflib
import pandas as pd
from django.db import connection
from django.forms import modelformset_factory,BaseModelFormSet
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from paginated_modelformset import PaginatedModelFormSet

def add(request):
    if request.method == "POST":
        form = DegreeForm(request.POST)
        if form.is_valid():
            # commit=False means the form doesn't save at this time.
            # commit defaults to True which means it normally saves.
            model_instance = form.save(commit=False)
            #model_instance.timestamp = timezone.now()
            model_instance.save()
            return redirect('degree:list')
    else:
        form = DegreeForm()
    return render(request, "degree_master.html", {'form': form})

def list(request):
    #colleges = MasterCollege.objects.all()
    degrees=MasterDegree.objects.raw("SELECT * FROM master_degree where source is null")
    #    for college in colleges:
    #       print ("Colleges List:"+college.college_name)
    #data = {}
    #data['object_list'] = colleges
    #print(type(data))
    #print(type(colleges))
    return render(request, 'degree_list.html', {'lstData':degrees})


def update(request, pk):
   # print("college update call.."+pk)
    degree = get_object_or_404(MasterDegree, pk=pk)
   # print (college.college_name)
    form = DegreeForm(request.POST or None, instance=degree)
     #print(form)
    #print(form['college_name'].value())
    if form.is_valid():
        form.save()
        return redirect('degree:list')
    return render(request,"degree_master.html",{'form':form})

def confirm_replace(request, pk,pk2):
   # print("college update call.."+pk)
   # college = get_object_or_404(MasterCollege, pk=pk)
    print("Confirm replace::"+pk +" :::"+pk2)
    if request.method=='POST':
        with connection.cursor() as cursor:
            cursor.execute("UPDATE user_qualification SET degree_id = %s WHERE degree_id = %s", [pk2,pk])
        degree = get_object_or_404(MasterDegree, pk=pk)
        degree.delete()
        return redirect('degree:list') 
    else:
       return render(request, 'degree_confirm_replace.html', {'pk':pk,'pk2':pk2})

def replace(request, pk):
   # print("college update call.."+pk)
    degree = get_object_or_404(MasterDegree, pk=pk)
   # print (college.college_name)
   # if request.method=='POST':
   #    return render('college_confirm_replace.html',{object : college})

    form = DegreeForm(request.POST or None, instance=degree)
    col_name=degree.degree_name
    col_name2=degree.degree_name
    col_name = [word for word in col_name.split() if word.lower() not in stopwords.words('english')]
    strwh=''
    lst2=[]
    j=0
    for cname in col_name:
        j+=1
        if ((j==len(col_name)) | (len(col_name)==1)):
            strwh=strwh +" degree_name like %s "
            lst2.append("%"+cname+"%")
            break
        else:
            strwh=strwh +" degree_name like %s or"
            lst2.append("%"+cname+"%")
    print(strwh)
    #qry="SELECT * FROM master_degree where degree_id!="+str(pk)+" and ("+strwh +")"
    qry="SELECT * FROM master_degree where degree_id!="+str(pk)
    print(qry)
    print(lst2)
    #["%high%","%school%"]
    degrees=MasterDegree.objects.raw(qry)
    print(type(degrees))
    dataLst=[]
    for obj1 in degrees:
        #print ("Colleges List:"+type(college.college_acronym))
        if (name_compare_n2(col_name2,obj1.degree_name)==1):
            dataLst.append(obj1)
        elif (obj1.degree_acronym != None):
            if (name_compare_n2(col_name2,obj1.degree_acronym)==1):
                dataLst.append(obj1)
    # print ("Colleges List:"+college.college_name)
    #print(colgLst)
    #data = {}
    #data['object_list'] = colleges    
    # print(colleges)
    #print(form['college_name'].value())
    if form.is_valid():
        form.save()
        return redirect('degree:list')
    return render(request,"degree_edit.html",{'form':form,'lstData':dataLst,'pk':pk})

def delete(request, pk, template_name='degree_delete.html'):
    degree = get_object_or_404(MasterDegree, pk=pk)
    if request.method=='POST':
        degree.delete()
        return redirect('degree:list')
    return render(request, template_name, {'object1':degree})


def name_compare_n2(val1,val2):
    seq = difflib.SequenceMatcher()
    r1=0;
    seq = difflib.SequenceMatcher()
    seq.set_seqs(val1, val2)
    if ((seq.ratio()*100)>50):
        print("match:"+val2)
        return 1
    else:
        return 0


def allupdates(request):
    search_val=''
    if request.method == 'GET': # If the form is submitted
        search_val = request.GET.get('search_box', None) 
        print(search_val) 
        if (search_val==None):
            search_val=''   
    if request.method == 'POST':
        dataFormSet = modelformset_factory(MasterDegree,form=DegreeForm)
        form_list = dataFormSet(request.POST)
        action = request.POST.get('action')
        if action==u'delete':
            form_list.save()
        else: 
            instances=form_list.save(commit=False)
            for instance in instances:
                instance.save()
    dataFormSet = modelformset_factory(MasterDegree, form=DegreeForm,formset=PaginatedModelFormSet)
    page = request.GET.get('page')
    print(page)
    try:
        form_list = dataFormSet(queryset = MasterDegree.objects.filter(degree_name__icontains=search_val),per_page=20, page_num=page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        form_list = dataFormSet(queryset = MasterDegree.objects.filter(degree_name__icontains=search_val),per_page=20, page_num=1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        form_list = dataFormSet(queryset = MasterDegree.objects.filter(degree_name__icontains=search_val),per_page=20, page_num=paginator.num_pages)
    form_lbl = DegreeForm()
    return render(request, 'edit_master.html', {'formset':form_list,'formlable':form_lbl,'search_val':search_val,'search_label':'Degree Name'})    
