from django.conf.urls import url
from django.contrib import admin
from django.views.generic import TemplateView
#from django.conf.urls import patterns, include
admin.autodiscover()
from degree import views
urlpatterns = [
    url(r'^newdegree/', views.add, name = 'add'),
    url(r'^$', views.list, name='list'),
    url(r'^edit/(?P<pk>\d+)$', views.update, name='update'),
    url(r'^replace/(?P<pk>\d+)$', views.replace, name='replace'),
    url(r'^replace_confirm/(?P<pk>\d+)/(?P<pk2>\d+)$', views.confirm_replace, name='confirm_replace'),
    url(r'^delete/(?P<pk>\d+)$', views.delete, name='delete'),
    url(r'^updates/', views.allupdates, name='updates'),    
]
