from django import forms
from django.forms import ModelForm
from degree.models import MasterDegree

class DegreeForm(ModelForm):
	class Meta:
		model = MasterDegree
		fields = ['degree_id','degree_name', 'source','degree_acronym','degree_rank']
		widgets = {
          'degree_name': forms.TextInput(attrs={'size':'50'}),
        }		