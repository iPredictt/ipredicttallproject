# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from __future__ import unicode_literals

from django.db import models


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=80)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)
    permission = models.ForeignKey('AuthPermission', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING)
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.IntegerField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.CharField(max_length=254)
    is_staff = models.IntegerField()
    is_active = models.IntegerField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user', 'group'),)


class AuthUserUserPermissions(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    permission = models.ForeignKey(AuthPermission, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class Candidate(models.Model):
    candidate_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100, blank=True, null=True)
    email = models.CharField(max_length=100, blank=True, null=True)
    contact_number = models.CharField(max_length=100, blank=True, null=True)
    address = models.CharField(max_length=255, blank=True, null=True)
    resume_path = models.CharField(max_length=255, blank=True, null=True)
    remarks = models.CharField(max_length=255, blank=True, null=True)
    date_of_birth = models.DateField(blank=True, null=True)
    gender = models.CharField(max_length=10, blank=True, null=True)
    nationality = models.CharField(max_length=100, blank=True, null=True)
    alternate_email = models.CharField(max_length=100, blank=True, null=True)
    category = models.CharField(max_length=100, blank=True, null=True)
    subcategory = models.CharField(max_length=100, blank=True, null=True)
    uuid = models.CharField(max_length=100, blank=True, null=True)
    tag_id = models.IntegerField(blank=True, null=True)
    chatbot_state = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    deleted_at = models.DateTimeField(blank=True, null=True)
    facebook_profile = models.CharField(max_length=255, blank=True, null=True)
    twitter_profile = models.CharField(max_length=255, blank=True, null=True)
    linkedin_profile = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate'


class CandidateExperience(models.Model):
    candidate_experience_id = models.AutoField(primary_key=True)
    candidate_id = models.IntegerField()
    company_name = models.CharField(max_length=100, blank=True, null=True)
    job_location = models.CharField(max_length=100, blank=True, null=True)
    designation = models.CharField(max_length=100, blank=True, null=True)
    alias = models.CharField(max_length=100, blank=True, null=True)
    formatted_name = models.CharField(max_length=100, blank=True, null=True)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    ctc = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_experience'


class CandidateQualification(models.Model):
    candidate_qualification_id = models.AutoField(primary_key=True)
    candidate_id = models.IntegerField()
    university_name = models.CharField(max_length=100, blank=True, null=True)
    university_city = models.CharField(max_length=100, blank=True, null=True)
    university_state = models.CharField(max_length=100, blank=True, null=True)
    university_country = models.CharField(max_length=100, blank=True, null=True)
    institute_name = models.CharField(max_length=100, blank=True, null=True)
    institute_city = models.CharField(max_length=100, blank=True, null=True)
    institute_state = models.CharField(max_length=100, blank=True, null=True)
    institute_country = models.CharField(max_length=100, blank=True, null=True)
    degree = models.CharField(max_length=100, blank=True, null=True)
    year = models.IntegerField(blank=True, null=True)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    aggregate = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_qualification'


class CandidateSkill(models.Model):
    candidate_skill_id = models.AutoField(primary_key=True)
    candidate_id = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    skill_type = models.CharField(max_length=100, blank=True, null=True)
    master_skill_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'candidate_skill'


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.SmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class DjangoSite(models.Model):
    domain = models.CharField(unique=True, max_length=100)
    name = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'django_site'


class Dreamreal(models.Model):
    website = models.CharField(max_length=50)
    mail = models.CharField(max_length=50)
    name = models.CharField(max_length=50)
    phonenumber = models.IntegerField()
    online = models.ForeignKey('Online', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'dreamreal'


class MasterCollege(models.Model):
    college_id = models.AutoField(primary_key=True)
    college_name = models.CharField(max_length=250, blank=True, null=True)
    college_acronym = models.CharField(max_length=45, blank=True, null=True)
    college_tier = models.IntegerField(blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.CharField(max_length=20, blank=True, null=True)
    updated_at = models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_college'


class MasterCompany(models.Model):
    company_id = models.AutoField(primary_key=True)
    company_name = models.CharField(max_length=400, blank=True, null=True)
    revenue = models.FloatField(blank=True, null=True)
    employee_count = models.FloatField(blank=True, null=True)
    industry = models.ForeignKey('MasterIndustry', models.DO_NOTHING, blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.CharField(max_length=20, blank=True, null=True)
    updated_at = models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_company'


class MasterDegree(models.Model):
    degree_id = models.AutoField(primary_key=True)
    degree_name = models.CharField(max_length=100)
    degree_acronym = models.CharField(max_length=100, blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.CharField(max_length=20, blank=True, null=True)
    updated_at = models.CharField(max_length=20, blank=True, null=True)
    degree_rank = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_degree'


class MasterDesignation(models.Model):
    designation_id = models.AutoField(primary_key=True)
    designation_name = models.CharField(max_length=200, blank=True, null=True)
    salary_entry_avg = models.FloatField(blank=True, null=True)
    salary_entry_min = models.FloatField(blank=True, null=True)
    salary_entry_max = models.FloatField(blank=True, null=True)
    salary_mid_avg = models.FloatField(blank=True, null=True)
    salary_mid_min = models.FloatField(blank=True, null=True)
    salary_mid_max = models.FloatField(blank=True, null=True)
    salary_exp_avg = models.FloatField(blank=True, null=True)
    salary_exp_min = models.FloatField(blank=True, null=True)
    salary_exp_max = models.FloatField(blank=True, null=True)
    industry_id = models.IntegerField(blank=True, null=True)
    function_id = models.IntegerField(blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_designation'


class MasterFunction(models.Model):
    function_id = models.AutoField(primary_key=True)
    function = models.CharField(max_length=200, blank=True, null=True)
    source = models.CharField(max_length=20, blank=True, null=True)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_function'


class MasterIndustry(models.Model):
    industry_id = models.AutoField(primary_key=True)
    industry = models.CharField(max_length=100, blank=True, null=True)
    source = models.CharField(max_length=20, blank=True, null=True)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_industry'


class MasterSkills(models.Model):
    skill_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    alias = models.TextField(blank=True, null=True)
    formatted_skill = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_skills'


class Online(models.Model):
    domain = models.CharField(max_length=30)

    class Meta:
        managed = False
        db_table = 'online'


class ServersClient(models.Model):
    name = models.CharField(max_length=100)
    address = models.CharField(max_length=200)
    contact_no = models.CharField(max_length=20)
    ctc = models.FloatField(blank=True, null=True)
    expected_ctc = models.FloatField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'servers_client'


class ServersServer(models.Model):
    name = models.CharField(max_length=200)
    ip = models.CharField(max_length=39)
    order = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'servers_server'


class UserExperience(models.Model):
    user_experience_id = models.IntegerField()
    user_id = models.IntegerField()
    company_id = models.IntegerField(blank=True, null=True)
    city_id = models.IntegerField(blank=True, null=True)
    designation_id = models.IntegerField()
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    ctc = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_experience'


class UserLogin(models.Model):
    login_id = models.AutoField(primary_key=True)
    login_email = models.CharField(max_length=45)
    password = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'user_login'


class UserProfile(models.Model):
    user_profile_id = models.IntegerField()
    user_id = models.IntegerField()
    first_name = models.CharField(max_length=100, blank=True, null=True)
    last_name = models.CharField(max_length=45, blank=True, null=True)
    contact_number = models.CharField(max_length=100, blank=True, null=True)
    city_id = models.IntegerField(blank=True, null=True)
    date_of_birth = models.CharField(max_length=45, blank=True, null=True)
    profile_photo = models.CharField(max_length=255, blank=True, null=True)
    marital_status = models.CharField(max_length=20, blank=True, null=True)
    gender = models.CharField(max_length=10, blank=True, null=True)
    nationality = models.CharField(max_length=100, blank=True, null=True)
    industry_id = models.IntegerField(blank=True, null=True)
    function_id = models.IntegerField(blank=True, null=True)
    resume_path = models.CharField(max_length=255, blank=True, null=True)
    facebook_profile_url = models.CharField(max_length=255, blank=True, null=True)
    twitter_profile_url = models.CharField(max_length=255, blank=True, null=True)
    linkedin_profile_url = models.CharField(max_length=255, blank=True, null=True)
    user_profile_score = models.FloatField(blank=True, null=True)
    user_experience_score = models.FloatField(blank=True, null=True)
    user_education_score = models.FloatField(blank=True, null=True)
    user_skill_score = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    deleted_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_profile'


class UserQualification(models.Model):
    user_qualification_id = models.AutoField(primary_key=True)
    user_id = models.IntegerField()
    college_id = models.IntegerField()
    degree_id = models.CharField(max_length=100, blank=True, null=True)
    start_year = models.DateTimeField(blank=True, null=True)
    end_year = models.DateTimeField(blank=True, null=True)
    aggregate = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_qualification'
