from django.apps import AppConfig

class DesignationConfig(AppConfig):
    name = 'designation'
