from django import forms
from django.forms import ModelForm
from designation.models import MasterDesignation

class DesignationForm(ModelForm):
	class Meta:
		model = MasterDesignation
		fields = ['designation_id','designation_name','salary_entry_avg','salary_entry_min','salary_entry_max',
				  'salary_mid_avg','salary_mid_min','salary_mid_max','salary_exp_avg','salary_exp_min',
				  'salary_exp_max','source']

