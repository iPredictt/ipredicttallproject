from django.db import models

# Create your models here.

class MasterFunction(models.Model):
    function_id = models.AutoField(primary_key=True)
    function = models.CharField(max_length=200, blank=True, null=True)
    source = models.CharField(max_length=20, blank=True, null=True)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_function'
    def __str__(self):
        return self.function  


class MasterIndustry(models.Model):
    industry_id = models.AutoField(primary_key=True)
    industry = models.CharField(max_length=100, blank=True, null=True)
    source = models.CharField(max_length=20, blank=True, null=True)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_industry'
    def __str__(self):
        return self.industry     

class MasterDesignation(models.Model):
    designation_id = models.AutoField(primary_key=True)
    designation_name = models.CharField(max_length=200, blank=True, null=True)
    salary_entry_avg = models.FloatField(blank=True, null=True)
    salary_entry_min = models.FloatField(blank=True, null=True)
    salary_entry_max = models.FloatField(blank=True, null=True)
    salary_mid_avg = models.FloatField(blank=True, null=True)
    salary_mid_min = models.FloatField(blank=True, null=True)
    salary_mid_max = models.FloatField(blank=True, null=True)
    salary_exp_avg = models.FloatField(blank=True, null=True)
    salary_exp_min = models.FloatField(blank=True, null=True)
    salary_exp_max = models.FloatField(blank=True, null=True)
    #industry = models.ForeignKey('MasterIndustry', models.DO_NOTHING, blank=True, null=True)
    #function = models.ForeignKey('MasterFunction', models.DO_NOTHING, blank=True, null=True)
    source_name= (
    ('admin', 'Admin'),
    ('web', 'Website'),
    )
    source = models.CharField(max_length=40,choices=source_name, default='admin')    
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_designation'

class UserExperience(models.Model):
    user_experience_id = models.IntegerField()
    user_id = models.IntegerField()
    company_id = models.IntegerField(blank=True, null=True)
    city_id = models.IntegerField(blank=True, null=True)
    designation_id = models.IntegerField()
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    ctc = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_experience'  