from django.shortcuts import render, redirect, get_object_or_404,render_to_response
# Create your views here.
from .forms import UserLoginForm
from login.models import UserLogin
from django.contrib import auth

#from college import views as college_m
#from degree import views as degree_m
#from company import views as company_m
#from designation import views as designation_m

# Create your views here.

def login(request):
	username = ''
	print('call form')
	if request.session.has_key('username'):
		username = request.session['username']       
		return render(request, 'home.html', {"username" : username})
	elif request.method == 'POST':
		print ('call form')
		form = UserLoginForm(request.POST)
		if form.is_valid():
			username = form.cleaned_data['login_email']
			password = form.cleaned_data['password']
			userLogin=UserLogin.objects.raw("SELECT * FROM db_user_login where login_email=%s and password=%s",[username,password])
			#print(type(userLogin))
			if (len(list(userLogin))>0):
				user = auth.authenticate(username=username, password=password)
				#auth.login(request, user)
				request.session['username'] = username
				return redirect('login:home')
			else:
				return render(request, 'login.html', {"form":form,"message" : 'Invalid username or password!'})    
	else:
		print ('call login')
		form = UserLoginForm()
		return render(request, 'login.html', {"form":form,"message" : ''})

def logout(request):
   try:
      del request.session['username']
      auth.logout(request)
   except:
      pass
   form = UserLoginForm()
   return redirect('login:login')

def home(request):
	if request.session.has_key('username'):
		username = request.session['username']
		return render(request, 'home.html', {"username" : username})
	else:
		form = UserLoginForm()
		return render(request, 'home.html', {"username" : ''})
		