from django.conf.urls import url
from django.contrib import admin
from django.views.generic import TemplateView
#from django.conf.urls import patterns, include
admin.autodiscover()
from login import views
urlpatterns = [
    url(r'^$', views.home, name = 'home'),
    url(r'^login/', views.login, name='login'),
    url(r'^logout/', views.logout, name='logout'),
]