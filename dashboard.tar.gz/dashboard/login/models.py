from django.db import models

# Create your models here.


class UserLogin(models.Model):
    login_id = models.AutoField(primary_key=True)
    login_email = models.CharField(max_length=45)
    password = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'db_user_login'