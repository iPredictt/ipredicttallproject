from django import forms
from django.forms import ModelForm
from login.models import UserLogin

class UserLoginForm(ModelForm):
	class Meta:
		model = UserLogin
		fields = ['login_email','password']

