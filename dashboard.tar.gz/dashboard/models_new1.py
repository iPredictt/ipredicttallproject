# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from __future__ import unicode_literals

from django.db import models


class AssesmentAnswer(models.Model):
    assesment_answer_id = models.AutoField(primary_key=True)
    question_id = models.IntegerField()
    user = models.ForeignKey('UserLogin', models.DO_NOTHING)
    answer = models.CharField(max_length=5)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'assesment_answer'


class AssesmentIndustry(models.Model):
    function_id = models.AutoField(primary_key=True)
    function_category = models.CharField(max_length=500)
    function = models.CharField(max_length=45, blank=True, null=True)
    r = models.IntegerField(db_column='R')  # Field name made lowercase.
    i = models.IntegerField(db_column='I')  # Field name made lowercase.
    a = models.IntegerField(db_column='A')  # Field name made lowercase.
    s = models.IntegerField(db_column='S')  # Field name made lowercase.
    e = models.IntegerField(db_column='E')  # Field name made lowercase.
    c = models.IntegerField(db_column='C')  # Field name made lowercase.
    comment = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'assesment_industry'


class AssesmentQuestion(models.Model):
    question_id = models.AutoField(primary_key=True)
    question_name = models.CharField(max_length=500)
    ans_code = models.CharField(max_length=5)

    class Meta:
        managed = False
        db_table = 'assesment_question'


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=80)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)
    permission = models.ForeignKey('AuthPermission', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING)
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.IntegerField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.CharField(max_length=254)
    is_staff = models.IntegerField()
    is_active = models.IntegerField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user', 'group'),)


class AuthUserUserPermissions(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    permission = models.ForeignKey(AuthPermission, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class ConsumerNotifications(models.Model):
    user_id = models.IntegerField()
    notifiable_type = models.CharField(max_length=100)
    update = models.CharField(max_length=191)
    notifiable_id = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'consumer_notifications'


class ConsumerService(models.Model):
    service_id = models.AutoField(db_column='Service_Id', primary_key=True)  # Field name made lowercase.
    mid = models.CharField(db_column='MID', max_length=45, blank=True, null=True)  # Field name made lowercase.
    order_id = models.CharField(db_column='Order_Id', max_length=45, blank=True, null=True)  # Field name made lowercase.
    txn_amount = models.FloatField(db_column='Txn_Amount', blank=True, null=True)  # Field name made lowercase.
    currency = models.CharField(db_column='Currency', max_length=10, blank=True, null=True)  # Field name made lowercase.
    txn_id = models.CharField(db_column='Txn_Id', max_length=45, blank=True, null=True)  # Field name made lowercase.
    banktxn_id = models.CharField(db_column='BankTxn_Id', max_length=45, blank=True, null=True)  # Field name made lowercase.
    status = models.CharField(db_column='Status', max_length=45, blank=True, null=True)  # Field name made lowercase.
    resp_code = models.CharField(db_column='Resp_Code', max_length=45, blank=True, null=True)  # Field name made lowercase.
    resp_msg = models.CharField(db_column='Resp_Msg', max_length=100, blank=True, null=True)  # Field name made lowercase.
    txn_date = models.DateTimeField(db_column='Txn_Date', blank=True, null=True)  # Field name made lowercase.
    gateway_name = models.CharField(db_column='Gateway_Name', max_length=45, blank=True, null=True)  # Field name made lowercase.
    bank_name = models.CharField(db_column='Bank_Name', max_length=45, blank=True, null=True)  # Field name made lowercase.
    payment_mode = models.CharField(db_column='Payment_Mode', max_length=45, blank=True, null=True)  # Field name made lowercase.
    checksumhash = models.CharField(db_column='ChecksumHash', max_length=255, blank=True, null=True)  # Field name made lowercase.
    candidate_id = models.CharField(db_column='Candidate_id', max_length=45, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'consumer_service'


class CurrentJobLevels(models.Model):
    title = models.CharField(max_length=191)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'current_job_levels'


class DbUserLogin(models.Model):
    login_id = models.IntegerField()
    login_email = models.CharField(max_length=45)
    password = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'db_user_login'


class DesignationList1(models.Model):
    candidate_id = models.IntegerField(blank=True, null=True)
    designation_id = models.IntegerField(blank=True, null=True)
    designation = models.CharField(max_length=200, blank=True, null=True)
    skill_name = models.CharField(max_length=200, blank=True, null=True)
    skill_id = models.FloatField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'designation_list1'


class DesignationMaster(models.Model):
    designation = models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'designation_master'


class DesignationSkillMatch(models.Model):
    index = models.BigIntegerField(blank=True, null=True)
    candidate_id = models.BigIntegerField(blank=True, null=True)
    designation_id = models.BigIntegerField(blank=True, null=True)
    designation = models.TextField(blank=True, null=True)
    skill_name = models.TextField(blank=True, null=True)
    skill_id = models.FloatField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'designation_skill_match'


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.SmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class EnterpriseUserExperience(models.Model):
    candidate_experience_id = models.BigAutoField(primary_key=True)
    candidate_id = models.BigIntegerField(blank=True, null=True)
    company_name = models.CharField(max_length=200, blank=True, null=True)
    job_location = models.CharField(max_length=200, blank=True, null=True)
    designation = models.CharField(max_length=200, blank=True, null=True)
    company_id = models.BigIntegerField(blank=True, null=True)
    mapped_company_name = models.CharField(max_length=200, blank=True, null=True)
    designation_id = models.BigIntegerField(blank=True, null=True)
    mapped_designation_name = models.CharField(max_length=200, blank=True, null=True)
    city_id = models.BigIntegerField(blank=True, null=True)
    mapped_city_name = models.CharField(max_length=200, blank=True, null=True)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'enterprise_user_experience'


class EnterpriseUserIndustryFunction(models.Model):
    candidate_industry_function_id = models.BigAutoField(primary_key=True)
    candidate_id = models.BigIntegerField(blank=True, null=True)
    function_id = models.IntegerField(blank=True, null=True)
    industry_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'enterprise_user_industry_function'


class EnterpriseUserName(models.Model):
    candidate_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'enterprise_user_name'


class EnterpriseUserQualification(models.Model):
    candidate_qualification_id = models.BigAutoField(primary_key=True)
    candidate_id = models.BigIntegerField(blank=True, null=True)
    university_name = models.CharField(max_length=200, blank=True, null=True)
    institute_name = models.CharField(max_length=200, blank=True, null=True)
    college_id = models.BigIntegerField(blank=True, null=True)
    mapped_college = models.CharField(max_length=200, blank=True, null=True)
    degree = models.CharField(max_length=200, blank=True, null=True)
    degree_id = models.BigIntegerField(blank=True, null=True)
    mapped_degree = models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'enterprise_user_qualification'


class EnterpriseUserSkill(models.Model):
    candidate_skill_id = models.AutoField(primary_key=True)
    candidate_id = models.IntegerField(blank=True, null=True)
    name = models.CharField(max_length=200, blank=True, null=True)
    mapped_skills = models.CharField(max_length=200, blank=True, null=True)
    skill_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'enterprise_user_skill'


class FunctionTypes(models.Model):
    function_category = models.CharField(db_column='Function Category', max_length=191)  # Field name made lowercase. Field renamed to remove unsuitable characters.
    title = models.CharField(max_length=191)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'function_types'


class FundCrowds(models.Model):
    fund_crowd_id = models.AutoField(primary_key=True)
    user_id = models.IntegerField()
    story = models.TextField(blank=True, null=True)
    need_fund_reason = models.TextField()
    course_of_study = models.CharField(max_length=191)
    course_expense = models.BigIntegerField()
    course_duration = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fund_crowds'


class FundLoans(models.Model):
    fund_loan_id = models.AutoField(primary_key=True)
    user_id = models.IntegerField()
    course = models.CharField(max_length=191)
    duration = models.IntegerField()
    expense = models.BigIntegerField()
    collateral_available = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fund_loans'


class IndustryTypes(models.Model):
    name = models.CharField(max_length=191)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'industry_types'


class JdExpM2(models.Model):
    candidate_id = models.BigIntegerField(blank=True, null=True)
    designation = models.TextField(blank=True, null=True)
    company_name = models.TextField(blank=True, null=True)
    name = models.TextField(blank=True, null=True)
    job_id = models.FloatField(blank=True, null=True)
    jobtitleid = models.FloatField(db_column='JobTitleId', blank=True, null=True)  # Field name made lowercase.
    positiontitle = models.TextField(db_column='positionTitle', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'jd_exp_m2'


class JdExpM3(models.Model):
    skill_name = models.TextField(blank=True, null=True)
    designation = models.TextField(db_column='Designation', blank=True, null=True)  # Field name made lowercase.
    totdes = models.BigIntegerField(db_column='TotDes', blank=True, null=True)  # Field name made lowercase.
    jobtitle = models.TextField(db_column='JobTitle', blank=True, null=True)  # Field name made lowercase.
    totpos = models.BigIntegerField(db_column='TotPos', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'jd_exp_m3'


class JobtitleM1(models.Model):
    positiontitle = models.TextField(db_column='positionTitle', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'jobtitle_m1'


class MasterCity(models.Model):
    city_id = models.AutoField(primary_key=True)
    city_name = models.CharField(max_length=100)
    latitude = models.CharField(max_length=45, blank=True, null=True)
    longitude = models.CharField(max_length=45, blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_city'


class MasterCollege(models.Model):
    college_id = models.AutoField(primary_key=True)
    college_name = models.CharField(max_length=300)
    college_acronym = models.CharField(max_length=45, blank=True, null=True)
    college_tier = models.IntegerField(blank=True, null=True)
    source = models.CharField(max_length=41, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_college'


class MasterCollegeOld(models.Model):
    college_id = models.AutoField(primary_key=True)
    college_name = models.CharField(max_length=250, blank=True, null=True)
    college_acronym = models.CharField(max_length=45, blank=True, null=True)
    college_tier = models.IntegerField(blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_college_old'


class MasterCompany(models.Model):
    company_id = models.AutoField(primary_key=True)
    company_name = models.CharField(max_length=400, blank=True, null=True)
    revenue = models.FloatField(blank=True, null=True)
    employee_count = models.FloatField(blank=True, null=True)
    industry_id = models.FloatField(blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    careeropportunitiesrating = models.FloatField(db_column='careerOpportunitiesRating', blank=True, null=True)  # Field name made lowercase.
    compensationandbenefitsrating = models.FloatField(db_column='compensationAndBenefitsRating', blank=True, null=True)  # Field name made lowercase.
    cultureandvaluesrating = models.FloatField(db_column='cultureAndValuesRating', blank=True, null=True)  # Field name made lowercase.
    industry = models.CharField(max_length=100, blank=True, null=True)
    overallrating = models.FloatField(db_column='overallRating', blank=True, null=True)  # Field name made lowercase.
    seniorleadershiprating = models.FloatField(db_column='seniorLeadershipRating', blank=True, null=True)  # Field name made lowercase.
    worklifebalancerating = models.FloatField(db_column='workLifeBalanceRating', blank=True, null=True)  # Field name made lowercase.
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_company'


class MasterCompanyOld(models.Model):
    company_id = models.AutoField(primary_key=True)
    company_name = models.CharField(max_length=400, blank=True, null=True)
    revenue = models.FloatField(blank=True, null=True)
    employee_count = models.FloatField(blank=True, null=True)
    industry_id = models.FloatField(blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_company_old'


class MasterCompanyOld2(models.Model):
    company_id = models.AutoField(primary_key=True)
    company_name = models.CharField(max_length=400, blank=True, null=True)
    revenue = models.FloatField(blank=True, null=True)
    employee_count = models.FloatField(blank=True, null=True)
    industry_id = models.FloatField(blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_company_old2'


class MasterCompanyOld3(models.Model):
    company_id = models.AutoField(primary_key=True)
    company_name = models.CharField(max_length=400, blank=True, null=True)
    revenue = models.FloatField(blank=True, null=True)
    employee_count = models.FloatField(blank=True, null=True)
    industry_id = models.FloatField(blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_company_old3'


class MasterDegree(models.Model):
    degree_id = models.AutoField(primary_key=True)
    degree_name = models.CharField(max_length=191, blank=True, null=True)
    degree_acronym = models.CharField(max_length=100, blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    degree_rank = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_degree'


class MasterDesignation(models.Model):
    designation_id = models.AutoField(primary_key=True)
    designation_name = models.CharField(max_length=200, blank=True, null=True)
    salary_entry_avg = models.FloatField(blank=True, null=True)
    salary_entry_min = models.FloatField(blank=True, null=True)
    salary_entry_max = models.FloatField(blank=True, null=True)
    salary_mid_avg = models.FloatField(blank=True, null=True)
    salary_mid_min = models.FloatField(blank=True, null=True)
    salary_mid_max = models.FloatField(blank=True, null=True)
    salary_exp_avg = models.FloatField(blank=True, null=True)
    salary_exp_min = models.FloatField(blank=True, null=True)
    salary_exp_max = models.FloatField(blank=True, null=True)
    industry_id = models.IntegerField(blank=True, null=True)
    function_id = models.IntegerField(blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_designation'


class MasterFunction(models.Model):
    function_id = models.AutoField(primary_key=True)
    function = models.CharField(max_length=200, blank=True, null=True)
    source = models.CharField(max_length=20, blank=True, null=True)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_function'


class MasterIndustry(models.Model):
    industry_id = models.AutoField(primary_key=True)
    industry = models.CharField(max_length=100, blank=True, null=True)
    source = models.CharField(max_length=20, blank=True, null=True)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_industry'


class MasterSkill(models.Model):
    skill_id = models.AutoField(primary_key=True)
    skill_name = models.CharField(max_length=200)
    function_id = models.IntegerField(blank=True, null=True)
    refined = models.IntegerField(blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_skill'


class Migrations(models.Model):
    migration = models.CharField(max_length=191)
    batch = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'migrations'


class MindQuestion(models.Model):
    mind_question_id = models.AutoField(primary_key=True)
    question_name = models.CharField(max_length=400)
    question_type = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    sort = models.IntegerField(blank=True, null=True)
    mind_question_category_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'mind_question'


class MindQuestionAnswer(models.Model):
    answer_id = models.AutoField(primary_key=True)
    mind_question_id = models.IntegerField()
    user = models.ForeignKey('UserLogin', models.DO_NOTHING)
    answer = models.CharField(max_length=191)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'mind_question_answer'


class MindQuestionCategories(models.Model):
    mind_question_category_id = models.AutoField(primary_key=True)
    category_name = models.CharField(max_length=191)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'mind_question_categories'


class MindQuestionOption(models.Model):
    option_id = models.AutoField(primary_key=True)
    mind_question_id = models.IntegerField()
    option_content = models.CharField(max_length=191)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'mind_question_option'


class OldFunctionTypes1(models.Model):
    title = models.CharField(max_length=191)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'old_function_types1'


class OldMasterDegree1(models.Model):
    degree_id = models.AutoField(primary_key=True)
    degree_name = models.CharField(max_length=100)
    degree_acronym = models.CharField(max_length=100, blank=True, null=True)
    source = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    degree_rank = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'old_master_degree1'


class Optins(models.Model):
    user_id = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'optins'


class PasswordResets(models.Model):
    email = models.CharField(max_length=255)
    token = models.CharField(max_length=255)
    created_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'password_resets'


class Post(models.Model):
    post_id = models.AutoField(primary_key=True)
    post_type = models.IntegerField()
    post_content = models.TextField(blank=True, null=True)
    post_resource = models.TextField(blank=True, null=True)
    user_id = models.IntegerField()
    post_visibility = models.IntegerField()
    meta_title = models.CharField(max_length=255, blank=True, null=True)
    meta_description = models.CharField(max_length=255, blank=True, null=True)
    meta_url = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'post'


class PostComment(models.Model):
    comment_id = models.AutoField(primary_key=True)
    content = models.TextField()
    user_id = models.IntegerField()
    post = models.ForeignKey(Post, models.DO_NOTHING)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'post_comment'


class PostLike(models.Model):
    like_id = models.AutoField(primary_key=True)
    user_id = models.IntegerField()
    post = models.ForeignKey(Post, models.DO_NOTHING)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'post_like'


class Refers(models.Model):
    linkid = models.CharField(max_length=15)
    user = models.ForeignKey('UserLogin', models.DO_NOTHING)
    clicks = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'refers'
        unique_together = (('linkid', 'user'),)


class Reportables(models.Model):
    user_id = models.IntegerField()
    reportable_type = models.CharField(max_length=100)
    reportable_id = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reportables'


class ReskillEvent(models.Model):
    reskill_event_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=191)
    amount = models.FloatField()
    banner = models.CharField(max_length=191, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    content = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reskill_event'


class ReskillEventAttendes(models.Model):
    user_id = models.IntegerField()
    reskill_event_id = models.IntegerField()
    order_id = models.CharField(max_length=36, blank=True, null=True)
    txn_id = models.CharField(max_length=191, blank=True, null=True)
    amount = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reskill_event_attendes'


class ReskillEventCoach(models.Model):
    coach_id = models.AutoField(primary_key=True)
    coach_name = models.CharField(max_length=191)
    coach_photo = models.CharField(max_length=191, blank=True, null=True)
    coach_company = models.CharField(max_length=191, blank=True, null=True)
    coach_role = models.CharField(max_length=191, blank=True, null=True)
    reskill_event_id = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reskill_event_coach'


class ReskillEventCounselor(models.Model):
    counselor_id = models.AutoField(primary_key=True)
    counselor_name = models.CharField(max_length=191)
    counselor_photo = models.CharField(max_length=191, blank=True, null=True)
    counselor_company = models.CharField(max_length=191, blank=True, null=True)
    counselor_role = models.CharField(max_length=191, blank=True, null=True)
    reskill_event_id = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reskill_event_counselor'


class ReskillEventExpert(models.Model):
    expert_id = models.AutoField(primary_key=True)
    expert_name = models.CharField(max_length=191)
    expert_photo = models.CharField(max_length=191, blank=True, null=True)
    reskill_event_id = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reskill_event_expert'


class ReskillYourselfCamps(models.Model):
    reskill_yourself_camp_id = models.AutoField(primary_key=True)
    camp_name = models.CharField(max_length=191)
    camp_amount = models.FloatField()
    camp_content = models.TextField()
    camp_date = models.DateField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reskill_yourself_camps'


class ReskillYourselfCampsUsers(models.Model):
    reskill_yourself_camp_id = models.IntegerField()
    user_id = models.IntegerField()
    order_id = models.CharField(max_length=36, blank=True, null=True)
    txn_id = models.CharField(max_length=191, blank=True, null=True)
    amount = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reskill_yourself_camps_users'


class ReskillYourselfCourseProfessions(models.Model):
    reskill_yourself_course_profession_id = models.AutoField(primary_key=True)
    reskill_yourself_course_id = models.IntegerField()
    reskill_yourself_profession_id = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reskill_yourself_course_professions'


class ReskillYourselfCourses(models.Model):
    reskill_yourself_course_id = models.AutoField(primary_key=True)
    course_name = models.CharField(max_length=191)
    course_amount = models.FloatField()
    course_content = models.TextField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reskill_yourself_courses'


class ReskillYourselfCoursesUsers(models.Model):
    reskill_yourself_course_id = models.IntegerField()
    user_id = models.IntegerField()
    order_id = models.CharField(max_length=36, blank=True, null=True)
    txn_id = models.CharField(max_length=191, blank=True, null=True)
    amount = models.FloatField(blank=True, null=True)
    reskill_yourself_profession_id = models.IntegerField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reskill_yourself_courses_users'


class ReskillYourselfProfessions(models.Model):
    reskill_yourself_profession_id = models.AutoField(primary_key=True)
    profession_name = models.CharField(max_length=191)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reskill_yourself_professions'


class Room(models.Model):
    room_id = models.AutoField(primary_key=True)
    room_name = models.CharField(max_length=191, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'room'


class RoomMessage(models.Model):
    message_id = models.AutoField(primary_key=True)
    content = models.TextField()
    type = models.IntegerField()
    room_id = models.IntegerField()
    user_id = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'room_message'


class RoomUser(models.Model):
    user_room_id = models.AutoField(primary_key=True)
    room_id = models.IntegerField()
    user_id = models.IntegerField()
    deleted = models.IntegerField()
    new_message_count = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'room_user'


class TempCompany(models.Model):
    id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'temp_company'


class UserCertification(models.Model):
    user_certification_id = models.AutoField(primary_key=True)
    user = models.ForeignKey('UserLogin', models.DO_NOTHING)
    certification_name = models.CharField(max_length=200, blank=True, null=True)
    certification_authority = models.CharField(max_length=200, blank=True, null=True)
    certification_url = models.CharField(max_length=500, blank=True, null=True)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_certification'


class UserExperience(models.Model):
    user_experience_id = models.AutoField(primary_key=True)
    user = models.ForeignKey('UserLogin', models.DO_NOTHING)
    company_id = models.IntegerField(blank=True, null=True)
    city_id = models.IntegerField(blank=True, null=True)
    designation_id = models.IntegerField()
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    ctc = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_experience'


class UserLogin(models.Model):
    user_id = models.AutoField(primary_key=True)
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=191)
    type = models.IntegerField()
    remember_token = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    deleted_at = models.DateTimeField(blank=True, null=True)
    mq_timestamp = models.DateTimeField(blank=True, null=True)
    con_timestamp = models.DateTimeField(blank=True, null=True)
    verification_code = models.CharField(max_length=36, blank=True, null=True)
    last_post_read = models.IntegerField(blank=True, null=True)
    referrer = models.TextField(blank=True, null=True)
    notification_read = models.DateTimeField(blank=True, null=True)
    user_type = models.IntegerField()
    show_assessment = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'user_login'


class UserMisc(models.Model):
    user_misc_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(UserLogin, models.DO_NOTHING)
    passport_number = models.CharField(max_length=100, blank=True, null=True)
    license_number = models.CharField(max_length=100, blank=True, null=True)
    pan_number = models.CharField(max_length=100, blank=True, null=True)
    visa_status = models.CharField(max_length=100, blank=True, null=True)
    hobbies = models.TextField(blank=True, null=True)
    objectives = models.TextField(blank=True, null=True)
    achievements = models.TextField(blank=True, null=True)
    references = models.TextField(blank=True, null=True)
    summary = models.TextField(blank=True, null=True)
    coverletter = models.TextField(blank=True, null=True)
    publication = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_misc'


class UserNetwork(models.Model):
    network_id = models.AutoField(primary_key=True)
    sender_user_id = models.IntegerField()
    receiver_user_id = models.IntegerField()
    status = models.IntegerField()
    type = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_network'


class UserProfile(models.Model):
    user_profile_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(UserLogin, models.DO_NOTHING)
    first_name = models.CharField(max_length=100, blank=True, null=True)
    last_name = models.CharField(max_length=45, blank=True, null=True)
    contact_number = models.CharField(max_length=100, blank=True, null=True)
    city_id = models.IntegerField(blank=True, null=True)
    date_of_birth = models.CharField(max_length=45, blank=True, null=True)
    profile_photo = models.CharField(max_length=255, blank=True, null=True)
    marital_status = models.CharField(max_length=20, blank=True, null=True)
    gender = models.CharField(max_length=10, blank=True, null=True)
    nationality = models.CharField(max_length=100, blank=True, null=True)
    industry_id = models.IntegerField(blank=True, null=True)
    function_id = models.IntegerField(blank=True, null=True)
    current_job_level_id = models.IntegerField(blank=True, null=True)
    designation_id = models.IntegerField(blank=True, null=True)
    resume_path = models.CharField(max_length=255, blank=True, null=True)
    facebook_profile_url = models.CharField(max_length=255, blank=True, null=True)
    twitter_profile_url = models.CharField(max_length=255, blank=True, null=True)
    linkedin_profile_url = models.CharField(max_length=255, blank=True, null=True)
    user_profile_score = models.FloatField(blank=True, null=True)
    user_experience_score = models.FloatField(blank=True, null=True)
    user_education_score = models.FloatField(blank=True, null=True)
    user_skill_score = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    deleted_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_profile'


class UserQualification(models.Model):
    user_qualification_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(UserLogin, models.DO_NOTHING)
    college_id = models.IntegerField()
    degree_id = models.CharField(max_length=100, blank=True, null=True)
    city_id = models.IntegerField(blank=True, null=True)
    aggregate = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    graduation = models.IntegerField()
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_qualification'


class UserSkill(models.Model):
    user_skill_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(UserLogin, models.DO_NOTHING)
    skill_id = models.IntegerField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_skill'
